# Project Page & Ruby
Well, as you can see, i added a list of featured projects to the page. The link
is just their in the navigation bar.

More content will come soon, i'm a little bit busy at the moment.

Of course i'm checking out the new HL1 remake Black Mesa Source!

Also a lot of work is going on. I'm currently creating some kind of monitoring
("watchdog") system for the companies i cooperate with. This project led me to
ruby. I read a tutorial about it, and started right away with the coding. The
language is a charm, i love the syntax as well as the structure.

hope to do more things in ruby ^^
